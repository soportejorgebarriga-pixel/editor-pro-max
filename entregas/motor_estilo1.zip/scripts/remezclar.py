"""Rehace SOLO el audio de un video ya renderizado (misma imagen, mismos cortes) y lo vuelve a unir.
Uso: python remezclar.py ficha.json version video_entrada.mp4 video_salida.mp4
Lee la ficha (audio_limpio, voz_estudio, musica, niveles) y el registro de cortes del render anterior."""
import json, os, subprocess, sys
import sonido, musica


def remezclar(ficha_path, version, vin, vout, tmp_render):
    d = os.path.dirname(os.path.abspath(ficha_path))
    f = json.load(open(ficha_path))
    reg = json.load(open(os.path.join(tmp_render, "registro.json")))
    tmp = os.path.join(d, "tmp_audio_" + version); os.makedirs(tmp, exist_ok=True)
    fv = dict(f)
    fv["clips"] = {k: v if v.startswith("/") else os.path.join(d, v) for k, v in f["clips"].items()}
    fv["audio_limpio"] = {k: v if v.startswith("/") else os.path.join(d, v) for k, v in f.get("audio_limpio", {}).items()}
    total = reg["total"]
    sonido.voz(reg["piezas"], fv, f["velocidad"], f"{tmp}/voz.wav", extra_cola=total - reg["voz_fin"] + 0.2)
    mu = None
    if f.get("musica"):
        m = f["musica"]
        ids = [t["id"] for t in f["tomas"]]
        orden = f["versiones"][version]["orden"]
        fin = reg["tomas"][orden.index(m["hasta_toma"])][1] if m.get("hasta_toma") else m["hasta"]
        mu = musica.tension(fin, bpm=m.get("bpm", 96), riser=m.get("riser", 2.6))
    sonido.mezclar(f"{tmp}/voz.wav", [tuple(e) for e in reg["sfx"]], total, f"{tmp}/final.wav", tmp,
                   ambiente=f.get("ambiente", 0.02), sfx=f.get("nivel_efectos", 1.0),
                   musica=mu, musica_db=f.get("musica", {}).get("db_bajo_voz", -20))
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", vin, "-i", f"{tmp}/final.wav", "-map", "0:v:0", "-map", "1:a:0",
                    "-c:v", "copy", "-c:a", "aac", "-ar", "48000", "-b:a", "192k", "-shortest", "-movflags", "+faststart", vout],
                   check=True)
    return vout


if __name__ == "__main__":
    fp, ver, vin, vout = sys.argv[1:5]
    tmp_render = sys.argv[5] if len(sys.argv) > 5 else os.path.join(os.path.dirname(os.path.abspath(fp)), "tmp_" + ver)
    print(remezclar(fp, ver, vin, vout, tmp_render))
