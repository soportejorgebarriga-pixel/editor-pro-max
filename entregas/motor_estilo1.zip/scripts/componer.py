"""Cuadro por cuadro -> video. Uso: python componer.py ficha.json [version] [--solo-segundos N]"""
import json, os, re, subprocess, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from config import *
import animaciones as A
import cortes, sonido, subtitulos

AQUI = os.path.dirname(os.path.abspath(__file__))
CARA = (535, 1070)   # se sobreescribe desde la ficha
ENCUADRE = {"original": 1.0, "medio": 1.22, "cerrado": 1.34}


def _norm(w):
    return re.sub(r"[^\wáéíóúñü$%]", "", w.lower())


class Video:
    def __init__(self, ficha_path, version=None):
        self.dir = os.path.dirname(os.path.abspath(ficha_path))
        f = json.load(open(ficha_path))
        self.ficha = f
        self.version = version or f.get("version_default", "A")
        orden = f["versiones"][self.version]["orden"]
        tomas = {t["id"]: t for t in f["tomas"]}
        self.tomas = [dict(tomas[i]) for i in orden]
        for k, v in f["versiones"][self.version].get("cambios", {}).items():
            for t in self.tomas:
                if t["id"] == k:
                    t.update(v)
        fv = dict(f, tomas=self.tomas)
        fv["clips"] = {k: os.path.join(self.dir, v) if not v.startswith("/") else v for k, v in f["clips"].items()}
        self.fv = fv
        global CARA
        CARA = tuple(f.get("cara", CARA))
        self.vel = f["velocidad"]
        pal = json.load(open(os.path.join(self.dir, f["palabras"])))
        self.piezas, self.words, self.tout = cortes.construir(fv, pal, self.vel)
        for ti, tm in enumerate(self.tomas):
            usados = set()
            for c in tm.get("claves", []):
                for w in self.words:
                    if w["toma"] == ti and _norm(w["text"]) == _norm(c) and c not in usados:
                        w["clave"] = True; usados.add(c)
        self.voz_fin = self.tout[-1][1]
        self.total = self.voz_fin + f.get("cierre", {}).get("extra", 0)
        self.nombre = f["nombre"] + "_" + self.version
        self.tmp = os.path.join(self.dir, "tmp_" + self.version)
        os.makedirs(self.tmp, exist_ok=True)
        self.imgs = {k: Image.open(os.path.join(self.dir, v)) for k, v in f.get("imagenes", {}).items()}
        self.eventos_sfx, self.cajas, self.cambios = [], [], []
        self.ultimo = None

    # ---------- utilidades de tiempo ----------
    def tw(self, ti, spec, default=0.0):
        """spec: número (s desde inicio de la toma) o palabra (primera coincidencia) o 'palabra#n'."""
        t0 = self.tout[ti][0]
        if spec is None:
            return t0 + default
        if isinstance(spec, (int, float)):
            return t0 + spec
        n = 0
        if "#" in spec:
            spec, n = spec.split("#"); n = int(n)
        ws = [w for w in self.words if w["toma"] == ti and _norm(spec) in _norm(w["text"])]
        return ws[min(n, len(ws) - 1)]["t0"] if ws else t0 + default

    # ---------- base ----------
    def base(self):
        out = os.path.join(self.tmp, "base.mp4")
        clips = list(self.fv["clips"])
        args = ["ffmpeg", "-v", "error", "-y"]
        for c in clips:
            args += ["-i", self.fv["clips"][c]]
        fc = []
        for i, p in enumerate(self.piezas):
            path = self.fv["clips"][p["clip"]]
            trc = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                                  "stream=color_transfer,width", "-of", "csv=p=0", path], capture_output=True, text=True).stdout
            pre = HDR2SDR + "," if ("arib" in trc or "2084" in trc) else ""
            fc.append(f"[{clips.index(p['clip'])}:v:0]trim={p['s']}:{p['e']},setpts=PTS-STARTPTS,{pre}"
                      f"scale={W}:{H}:flags=lanczos,setsar=1,format=yuv420p[v{i}]")
        fc.append("".join(f"[v{i}]" for i in range(len(self.piezas))) +
                  f"concat=n={len(self.piezas)}:v=1:a=0,setpts=PTS/{self.vel},fps={FPS},"
                  f"unsharp=5:5:0.6,{EQ_PRESENTE}[out]")
        subprocess.run(args + ["-filter_complex", ";".join(fc), "-map", "[out]", "-c:v", "libx264",
                               "-crf", "12", "-preset", "veryfast", "-pix_fmt", "yuv420p", out], check=True)
        return out

    # ---------- fondos ----------
    def fondo_jorge(self, fr, ti, t):
        spec = self.tomas[ti].get("fondo", {})
        a, b = self.tout[ti]
        s0 = ENCUADRE[spec.get("encuadre", "medio")]
        cy0 = H / 2 if s0 == 1.0 else H - H / (2 * s0)
        cx0 = spec.get("cx", 540)
        lento = spec.get("lento", 0.06)
        p = (t - a) / max(0.01, b - a)
        s = s0 * (1 + lento * p)
        muestras = [s]
        for g in spec.get("golpe", []):
            tg = self.tw(ti, g)
            if t >= tg:
                k = A.ease((t - tg) / ZOOM_GOLPE_S)
                s *= 1 + ZOOM_GOLPE_PCT * k
                if k < 1:   # desenfoque de movimiento: promedio de escalas intermedias
                    muestras = [s / (1 + ZOOM_GOLPE_PCT * k) * (1 + ZOOM_GOLPE_PCT * kk) for kk in np.linspace(max(0, k - .35), k, 4)]
                else:
                    muestras = [s]
            else:
                muestras = [s]
        imgs = []
        for ss in muestras:
            ww, hh = W / ss, H / ss
            cx = CARA[0] + (cx0 - CARA[0]) * (s0 / ss)
            cy = CARA[1] + (cy0 - CARA[1]) * (s0 / ss)
            x0 = min(max(cx - ww / 2, 0), W - ww); y0 = min(max(cy - hh / 2, 0), H - hh)
            imgs.append(fr.resize((W, H), Image.BILINEAR, box=(x0, y0, x0 + ww, y0 + hh)))
        if len(imgs) == 1:
            return imgs[0]
        acc = np.mean([np.asarray(i, np.float32) for i in imgs], 0)
        return Image.fromarray(acc.astype(np.uint8))

    def fondo_imagen(self, ti, t):
        spec = self.tomas[ti]["fondo"]
        img = self.imgs[spec["src"]]
        a, b = self.tout[ti]
        p = A.ease((t - a) / max(0.01, b - a)) * 0.7 + 0.3 * (t - a) / max(0.01, b - a)
        d, h_ = spec["desde"], spec["hasta"]
        cx, cy, z = [d[i] + (h_[i] - d[i]) * p for i in range(3)]
        iw, ih = img.size
        hh = ih / z; ww = hh * W / H
        if ww > iw:
            ww = iw; hh = ww * H / W
        x0 = min(max(cx * iw - ww / 2, 0), iw - ww); y0 = min(max(cy * ih - hh / 2, 0), ih - hh)
        out = img.convert("RGB").resize((W, H), Image.BICUBIC, box=(x0, y0, x0 + ww, y0 + hh))
        if spec.get("desenfoque"):
            out = out.filter(ImageFilter.GaussianBlur(spec["desenfoque"]))
            out = Image.blend(out, Image.new("RGB", (W, H), AZUL), spec.get("velo", 0.45))
        return out

    def lienzo_producto(self):
        if not hasattr(self, "_lienzo"):
            y, x = np.mgrid[0:H, 0:W]
            r = np.sqrt(((x - 540) / 900) ** 2 + ((y - 900) / 900) ** 2)
            k = np.clip(1 - r, 0, 1)[..., None] ** 2 * 0.35
            arr = np.array(AZUL, np.float32) * (1 - k) + np.array(VERDE, np.float32) * k
            self._lienzo = Image.fromarray(arr.astype(np.uint8))
        return self._lienzo

    def fondo_producto(self, ti, t):
        spec = self.tomas[ti]["fondo"]
        img = self.imgs[spec["src"]]
        a, b = self.tout[ti]
        p = (t - a) / max(0.01, b - a)
        p = 0.3 * p + 0.7 * A.ease(p)
        d, h_ = spec["desde"], spec["hasta"]
        fx, fy, z = [d[i] + (h_[i] - d[i]) * p for i in range(3)]
        cyp = spec.get("y", 920)
        wimg = 1040 * z
        sc = wimg / img.width
        im = img.resize((int(img.width * sc), int(img.height * sc)), Image.BICUBIC)
        canvas = self.lienzo_producto().copy().convert("RGBA")
        canvas.alpha_composite(im, (int(540 - fx * im.width), int(cyp - fy * im.height)) if True else (0, 0))
        return canvas.convert("RGB")

    # ---------- elementos ----------
    def elementos(self, canvas, fondo, ti, t):
        for el in self.tomas[ti].get("elementos", []):
            tipo = el["tipo"]
            t0 = self.tw(ti, el.get("en"), 0.0) + el.get("retraso", 0)
            if t < t0 - 0.01:
                continue
            if "hasta" in el and t > self.tw(ti, el["hasta"]):
                continue
            if tipo == "titulo":
                t_oro = self.tw(ti, el["oro_en"]) if el.get("oro_en") else None
                yb = A.titulo(canvas, t, t0, el["lineas"], el["y"], el.get("size", T_TITULO), oro=el.get("oro"),
                              t_oro=t_oro, barra=el.get("barra", True))
                w = max(A.ancho(l, ANTON, el.get("size", T_TITULO)) for l in el["lineas"])
                self.cajas.append((el["lineas"][0], SUB_X - w / 2, el["y"], SUB_X + w / 2, yb))
            elif tipo == "lista":
                items = [(it[0], self.tw(ti, it[1])) for it in el["items"]]
                box = A.lista(canvas, fondo, t, items, el.get("x", 70), el["y"], el.get("ancho", 790),
                              titulo_txt=el.get("encabezado"))
                if box: self.cajas.append(("lista",) + tuple(box))
            elif tipo == "etiqueta":
                p = A.prog(t, t0, 0.3)
                im = A.linea(((el["texto"], BLANCO),), el.get("size", T_ETIQ), DMSANS_B)
                w, h = im.width + 64, im.height + 34
                x = SUB_X - w / 2
                A.vidrio(canvas, fondo, (x, el["y"], x + w, el["y"] + h * p), radio=h // 2)
                A.subir(canvas, im, x + 32, el["y"] + 14, p)
                self.cajas.append((el["texto"], x, el["y"], x + w, el["y"] + h))
            elif tipo == "precio":
                p = A.prog(t, t0, 0.25)
                y = el["y"]; box = (110, y, 850, y + 272 * p)
                A.vidrio(canvas, fondo, box)
                pc = A.prog(t, t0 + 0.1, 0.5)
                val = A.contador(el["valor"], pc)
                big = A.linea(((f"${val}", DORADO), (" USD", BLANCO)), 150)
                A.subir(canvas, big, SUB_X - big.width / 2, y + 18, A.prog(t, t0 + 0.08, 0.3))
                sm = A.linea(((el["sub"], BLANCO),), 42, DMSANS)
                A.subir(canvas, sm, SUB_X - sm.width / 2, y + 198, A.prog(t, t0 + 0.3, 0.3))
                self.cajas.append(("precio",) + box[:3] + (y + 272,))
            elif tipo == "cierre":
                self.cierre(canvas, t, t0, el)

    def cierre(self, canvas, t, t0, el):
        p = A.prog(t, t0, 0.25)
        if not hasattr(self, "_cierre_bg"):
            img = self.imgs[el["fondo"]].convert("RGB")
            iw, ih = img.size; ww = ih * W / H
            bg = img.resize((W, H), Image.BICUBIC, box=(iw * 0.62 - ww / 2, 0, iw * 0.62 + ww / 2, ih))
            bg = bg.filter(ImageFilter.GaussianBlur(28))
            self._cierre_bg = Image.blend(bg, Image.new("RGB", (W, H), AZUL), 0.72).convert("RGBA")
        bg = self._cierre_bg.copy(); bg.putalpha(int(255 * p))
        canvas.alpha_composite(bg)
        yb = A.titulo(canvas, t, t0 + 0.1, el["lineas"], el["y"], el.get("size", T_TITULO), oro=el.get("oro"))
        self.cajas.append(("cierre-titulo", 120, el["y"], 860, yb))
        if el.get("producto"):
            img = self.imgs[el["producto"]]
            pp = A.prog(t, t0 + 0.35, 0.4)
            if pp > 0:
                sc = 760 / img.width * (0.92 + 0.08 * pp)
                im = img.resize((int(img.width * sc), int(img.height * sc)), Image.BICUBIC)
                a = im.getchannel("A").point(lambda v: int(v * pp)); im.putalpha(a)
                y = yb + 40 + int((1 - pp) * 30)
                canvas.alpha_composite(im, (int(SUB_X - im.width / 2), y))
                self.cajas.append(("cierre-producto", SUB_X - im.width / 2, y, SUB_X + im.width / 2, y + im.height))
        if el.get("sub"):
            sm = A.linea(((el["sub"], BLANCO),), 46, DMSANS)
            A.subir(canvas, sm, SUB_X - sm.width / 2, el["y_sub"], A.prog(t, t0 + 0.5, 0.3))
        A.pastilla(canvas, t, t0 + 0.7, el["pastilla"], SUB_X, el["y_pastilla"])
        self.cajas.append(("pastilla", SUB_X - 300, el["y_pastilla"], SUB_X + 300, el["y_pastilla"] + 92 + 22 + 82))

    # ---------- transiciones ----------
    def empuje(self, saliente, entrante, k):
        """Empuje lateral con desenfoque de movimiento; la saliente se oscurece y queda atrás."""
        e = A.ease(k)
        out = Image.new("RGB", (W, H))
        s_dark = Image.blend(saliente, Image.new("RGB", (W, H)), 0.55 * e)
        out.paste(s_dark, (int(-0.3 * W * e), 0))
        xin = int(W * (1 - e))
        if k < 1:
            arr = np.asarray(entrante, np.float32)
            acc = sum(np.roll(arr, int(d), axis=1) for d in np.linspace(0, 60 * (1 - e), 4)) / 4
            entrante = Image.fromarray(acc.astype(np.uint8))
        out.paste(entrante, (xin, 0))
        return out

    # ---------- render ----------
    def frame(self, base_fr, t):
        ti = next((i for i, (a, b) in enumerate(self.tout) if a <= t < b), len(self.tout) - 1)
        spec = self.tomas[ti].get("fondo", {"tipo": "jorge"})
        tipo = spec.get("tipo", "jorge")
        if tipo == "jorge":
            fondo = self.fondo_jorge(base_fr, ti, t)
        elif tipo == "imagen":
            fondo = self.fondo_imagen(ti, t)
        else:
            fondo = self.fondo_producto(ti, t)
        canvas = fondo.convert("RGBA")
        self.elementos(canvas, fondo, ti, t)
        out = canvas.convert("RGB")
        a, b = self.tout[ti]
        if self.tomas[ti].get("transicion") == "empuje" and t - a < 0.3 and getattr(self, "_salida", None) is not None:
            out = self.empuje(self._salida, out, (t - a) / 0.3)
        if ti + 1 < len(self.tout) and b - t <= 1.5 / FPS:
            self._salida = out
        return out

    def sfx_auto(self):
        ev = []
        for ti, tm in enumerate(self.tomas):
            a, b = self.tout[ti]
            if tm.get("transicion") == "empuje":
                ev.append(("barrido", a - 0.12))
            for g in tm.get("fondo", {}).get("golpe", []):
                ev.append(("golpe", self.tw(ti, g)))
            for el in tm.get("elementos", []):
                t0 = self.tw(ti, el.get("en"), 0) + el.get("retraso", 0)
                if el["tipo"] == "titulo":
                    ev.append(("golpe", t0 + 0.05))
                elif el["tipo"] == "lista":
                    for it in el["items"]:
                        ev += [("pop", self.tw(ti, it[1])), ("tic", self.tw(ti, it[1]) + 0.2)]
                elif el["tipo"] == "etiqueta":
                    ev.append(("pop", t0))
                elif el["tipo"] == "precio":
                    ev += [("pop", t0)] + [("tic", t0 + 0.1 + 0.5 * k / 6) for k in range(6)]
                elif el["tipo"] == "cierre":
                    ev += [("barrido", t0 - 0.1), ("golpe", t0 + 0.12), ("pop", t0 + 0.72)]
        # golpes muy juntos: quedarse con uno
        ev.sort(key=lambda e: e[1])
        res = []
        for e in ev:
            if res and e[0] == res[-1][0] and e[1] - res[-1][1] < 0.25:
                continue
            res.append(e)
        return res

    def render(self, salida, limite=None):
        total = self.total if limite is None else min(self.total, limite)
        base = self.base()
        # sonido
        sonido.voz(self.piezas, self.fv, self.vel, os.path.join(self.tmp, "voz.wav"), extra_cola=self.total - self.voz_fin + 0.2)
        self.eventos_sfx = self.sfx_auto()
        sonido.mezclar(os.path.join(self.tmp, "voz.wav"), self.eventos_sfx, total, os.path.join(self.tmp, "final.wav"), self.tmp)
        # subtítulos
        ocultar = []
        for ti, tm in enumerate(self.tomas):
            for el in tm.get("elementos", []):
                if el.get("oculta_subs"):
                    ocultar.append([self.tout[ti][0] - 0.2, self.tout[ti][1] if el["tipo"] != "cierre" else self.total + 1])
        self.fv["sin_subtitulos"] = ocultar
        ass = os.path.join(self.tmp, "subs.ass")
        self.subs = subtitulos.escribir_ass(ass, self.words, self.fv, total)
        # cuadros
        rd = subprocess.Popen(["ffmpeg", "-v", "error", "-i", base, "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
                              stdout=subprocess.PIPE)
        enc = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}",
                                "-r", str(FPS), "-i", "-", "-i", os.path.join(self.tmp, "final.wav"),
                                "-vf", f"ass={ass}", "-t", f"{total:.3f}"] + X264 + AAC + ["-r", str(FPS), salida],
                               stdin=subprocess.PIPE)
        n = int(round(total * FPS))
        fr = None
        for i in range(n):
            buf = rd.stdout.read(W * H * 3)
            if len(buf) == W * H * 3:
                fr = Image.frombuffer("RGB", (W, H), buf, "raw", "RGB", 0, 1)
            out = self.frame(fr, i / FPS)
            enc.stdin.write(out.tobytes())
            if i % 90 == 0:
                print(f"  cuadro {i}/{n}", flush=True)
        enc.stdin.close(); enc.wait(); rd.kill()
        json.dump(dict(tomas=self.tout, piezas=self.piezas, words=self.words, subs=self.subs, cajas=self._cajas_unicas(),
                       sfx=self.eventos_sfx, total=total, voz_fin=self.voz_fin,
                       cambios=self.cambios_visuales()), open(os.path.join(self.tmp, "registro.json"), "w"),
                  ensure_ascii=False, default=float)
        return salida

    def _cajas_unicas(self):
        d = {}
        for c in self.cajas:
            k = c[0]
            if k not in d:
                d[k] = list(c[1:])
            else:
                d[k] = [min(d[k][0], c[1]), min(d[k][1], c[2]), max(d[k][2], c[3]), max(d[k][3], c[4])]
        return d

    def cambios_visuales(self):
        ts = [a for a, b in self.tout]
        for ti, tm in enumerate(self.tomas):
            for g in tm.get("fondo", {}).get("golpe", []):
                ts.append(self.tw(ti, g))
            for el in tm.get("elementos", []):
                ts.append(self.tw(ti, el.get("en"), 0) + el.get("retraso", 0))
                for it in el.get("items", []):
                    ts.append(self.tw(ti, it[1]))
                if el["tipo"] == "cierre":   # producto y pastilla entran después del título
                    t0 = self.tw(ti, el.get("en"), 0)
                    ts += [t0 + 0.35, t0 + 0.7, t0 + 1.25]
        return sorted(set(round(x, 2) for x in ts))


if __name__ == "__main__":
    ficha = sys.argv[1]
    ver = sys.argv[2] if len(sys.argv) > 2 and not sys.argv[2].startswith("--") else None
    lim = float(sys.argv[sys.argv.index("--solo") + 1]) if "--solo" in sys.argv else None
    v = Video(ficha, ver)
    out = os.path.join(v.dir, "salida", f"{v.nombre}.mp4")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    print("duración:", round(v.total, 2), "s")
    v.render(out, lim)
    print("listo:", out)
