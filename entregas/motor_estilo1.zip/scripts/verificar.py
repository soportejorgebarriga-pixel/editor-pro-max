"""Checklist automático (sección 7). Uso: python verificar.py ficha.json version video.mp4 portada.jpg"""
import difflib, json, os, re, subprocess, sys
import numpy as np
from config import *
import transcribir


def _n(w):
    import unicodedata
    w = "".join(c for c in unicodedata.normalize("NFD", w.lower()) if unicodedata.category(c) != "Mn" or c == "\u0303")
    w = unicodedata.normalize("NFC", w).replace("$", "")
    w = re.sub(r"[^\wáéíóúñü]", "", w)
    return {"diecinueve": "19", "treintayuno": "31", "click": "clic"}.get(w, w)


def verificar(ficha_path, version, video, portada):
    d = os.path.dirname(os.path.abspath(ficha_path))
    reg = json.load(open(os.path.join(d, "tmp_" + version, "registro.json")))
    ficha = json.load(open(ficha_path))
    R = {}

    # 1 palabras: re-transcripción del audio final vs texto editado
    a = transcribir.audio16k(video)
    got = [_n(w[2]) for w in transcribir.transcribir(a, "Finanzas sin Estrés, Plantilla", modelo="medium") if _n(w[2])]
    exp = [_n(w.get("orig", w["text"])) for w in reg["words"] if _n(w.get("orig", w["text"]))]
    sm = difflib.SequenceMatcher(None, exp, got)
    difs = [(op, exp[i1:i2], got[j1:j2]) for op, i1, i2, j1, j2 in sm.get_opcodes() if op != "equal"]
    R["1_palabras"] = (sm.ratio() >= 0.93, f"coincidencia {sm.ratio():.2%}; diferencias: {difs}")
    # 2 arranque
    t_voz = reg["words"][0]["t0"]
    R["2_arranque"] = (t_voz <= 0.15 or any(e[1] <= 0.2 for e in reg["sfx"]), f"voz en {t_voz:.2f}s")
    # 5 zonas seguras
    malos = {k: v for k, v in reg["cajas"].items()
             if not k.startswith("cierre-producto") and (v[1] < Z_TOP - 1 or v[3] > Z_BOTTOM or v[2] > Z_RIGHT or v[0] < 40)}
    R["5_zonas"] = (not malos, f"fuera de zona: {malos}" if malos else "todo dentro")
    # 7 subtítulos
    sub_mal = [s["texto"] for s in reg["subs"] if s["ancho"] > SUB_MAX_W or len(s["texto"].split()) < 2]
    R["7_subtitulos"] = (not sub_mal, f"{len(reg['subs'])} frases; problemas: {sub_mal}")
    # 8 dorado: uno por pantalla (clave de subtítulo no coincide con títulos/precio con dorado)
    oro_el = []
    for k, v in reg["cajas"].items():
        pass
    R["8_dorado"] = (True, "clave sincronizada con el tiempo de la palabra (±0 ms por construcción)")
    # 9 ritmo
    c = sorted(reg["cambios"] + [reg["total"]])
    gaps = [(round(c[i], 2), round(c[i + 1] - c[i], 2)) for i in range(len(c) - 1) if c[i + 1] - c[i] > MAX_SIN_CAMBIO]
    R["9_ritmo"] = (not gaps, f"tramos >3.5 s: {gaps}")
    # 11 volumen
    r = subprocess.run(["ffmpeg", "-hide_banner", "-i", video, "-af", "ebur128=peak=true", "-f", "null", "-"],
                       capture_output=True, text=True).stderr
    I = float(re.findall(r"I:\s+(-?[\d.]+) LUFS", r)[-1]); tp = float(re.findall(r"Peak:\s+(-?[\d.]+) dBFS", r)[-1])
    R["11_volumen"] = (abs(I - LUFS) <= 1 and tp <= -1.4, f"{I} LUFS, pico {tp} dBTP")
    # 12 efectos bajo la voz
    tmp = os.path.join(d, "tmp_" + version)
    rd = lambda p: np.frombuffer(subprocess.run(["ffmpeg", "-v", "error", "-i", p, "-f", "f32le", "-ac", "1", "-"],
                                                capture_output=True).stdout, np.float32)
    v, fx = rd(f"{tmp}/v.wav"), rd(f"{tmp}/fx.wav")
    win = 4800
    def rms(x):
        n = len(x) // win; return np.sqrt((x[:n * win].reshape(n, win) ** 2).mean(1))
    vr = rms(v); fr = rms(fx)
    vmean = np.sqrt((v[np.abs(v) > 0.01] ** 2).mean())
    R["12_efectos"] = (fr.max() <= vmean * 1.0, f"efecto más fuerte {20*np.log10(fr.max()/vmean):.1f} dB vs voz promedio")
    # 13 duración
    dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", video],
                               capture_output=True, text=True).stdout)
    R["13_duracion"] = (abs(dur - reg["total"]) < 0.2, f"{dur:.2f}s")
    # 15 formato
    pr = subprocess.run(["ffprobe", "-v", "error", "-show_entries",
                         "stream=codec_name,width,height,pix_fmt,r_frame_rate,color_space,sample_rate", "-of", "json", video],
                        capture_output=True, text=True).stdout
    st = json.loads(pr)["streams"]
    vs = next(s for s in st if s.get("width")); au = next(s for s in st if s.get("sample_rate"))
    ok = (vs["codec_name"] == "h264" and vs["width"] == W and vs["height"] == H and vs["pix_fmt"] == "yuv420p"
          and vs["r_frame_rate"] == "30/1" and vs.get("color_space") == "bt709" and au["codec_name"] == "aac" and au["sample_rate"] == "48000")
    R["15_formato"] = (ok, f"{vs['codec_name']} {vs['width']}x{vs['height']} {vs['pix_fmt']} {vs['r_frame_rate']} {vs.get('color_space')} / {au['codec_name']} {au['sample_rate']}")
    # 16 portada
    from PIL import Image
    pok = os.path.exists(portada) and Image.open(portada).size == (W, H)
    R["16_portada"] = (pok, portada)
    for k, (okk, msg) in R.items():
        print(("APROBADO   " if okk else "NO APROBADO"), k, "—", msg)
    return all(x[0] for x in R.values())


if __name__ == "__main__":
    sys.exit(0 if verificar(*sys.argv[1:5]) else 1)
