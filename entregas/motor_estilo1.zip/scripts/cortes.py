"""Lista de cortes: tomas -> piezas sin pausas > 0.3 s, bordes ajustados por energía (10 ms)."""
import numpy as np
from config import PAUSA_MAX, MARGEN_PRE, MARGEN_POST
from transcribir import audio16k

SR = 16000
_audio = {}


def _rms(a):
    n = len(a) // 160
    return np.sqrt((a[:n * 160].reshape(n, 160) ** 2).mean(1) + 1e-12)


def _ajustar(clip_path, s, e, lim_s, lim_e):
    """Extiende el final mientras haya energía de voz (sílaba completa) y adelanta el inicio igual."""
    if clip_path not in _audio:
        a = audio16k(clip_path)
        r = _rms(a)
        _audio[clip_path] = (r, np.percentile(r, 20) * 2.5)
    r, thr = _audio[clip_path]
    # si el borde cae en silencio, acercarlo a la voz (máx. 0.4 s)
    i = int(e * 100)
    while i > int(s * 100) + 10 and r[i - 1] < thr and i > int((e - 0.4) * 100):
        i -= 1
    j0 = int(s * 100)
    while j0 < i - 10 and r[j0] < thr and j0 < int((s + 0.4) * 100):
        j0 += 1
    s = j0 / 100
    e = i / 100
    while i < len(r) and r[i] > thr and (i + 1) / 100 < min(e + 0.15, lim_e):
        i += 1
    e2 = min(i / 100 + MARGEN_POST, lim_e)
    j = int(s * 100)
    while j > 0 and r[j - 1] > thr and (j - 1) / 100 > max(s - 0.10, lim_s):
        j -= 1
    s2 = max(j / 100 - MARGEN_PRE, lim_s, 0)
    return s2, e2


def construir(ficha, palabras, velocidad):
    """Devuelve piezas (en tiempo fuente) y palabras/tomas en tiempo de salida."""
    piezas, words_out, tomas_out = [], [], []
    t = 0.0
    for ti, toma in enumerate(ficha["tomas"]):
        clip = toma["clip"]
        path = ficha.get("audio_limpio", {}).get(clip, ficha["clips"][clip])
        ws = [w for w in palabras[clip] if w[0] >= toma["desde"] - 0.05 and w[1] <= toma["hasta"] + 0.05]
        if toma.get("quitar"):
            ws = [w for k, w in enumerate(ws) if k not in toma["quitar"]]
        grupos, g = [], [ws[0]]
        for w in ws[1:]:
            if w[0] - g[-1][1] > PAUSA_MAX:
                grupos.append(g); g = [w]
            else:
                g.append(w)
        grupos.append(g)
        t_ini = t
        idx = {id(w): k for k, w in enumerate(ws)}
        corr = toma.get("corregir", {})
        for gi, g in enumerate(grupos):
            # vecinos reales en el clip (también las palabras que se quitaron): su sonido no se cuela
            todas = palabras[clip]
            prev_e = max([w[1] for w in todas if w[1] <= g[0][0] + 0.001 and w not in g] or [g[0][0] - 0.3])
            next_s = min([w[0] for w in todas if w[0] >= g[-1][1] - 0.001 and w not in g] or [g[-1][1] + 0.3])
            lim_s = max(prev_e + 0.02, g[0][0] - 0.15) if g[0][0] - prev_e > 0.04 else g[0][0]
            lim_e = min(next_s - 0.02, g[-1][1] + 0.2) if next_s - g[-1][1] > 0.04 else g[-1][1]
            s, e = _ajustar(path, g[0][0], g[-1][1], lim_s, lim_e)
            if gi == 0 and toma.get("pre") is not None:
                s = max(0, g[0][0] - toma["pre"])
            if gi == 0 and toma.get("inicio") is not None:      # borde exacto confirmado a oído/energía
                s = toma["inicio"]
            if gi == len(grupos) - 1 and toma.get("fin") is not None:
                e = toma["fin"]
            if gi == len(grupos) - 1 and toma.get("post") is not None:
                e = g[-1][1] + toma["post"]
            piezas.append(dict(toma=ti, clip=clip, s=round(s, 3), e=round(e, 3), out_s=t))
            for w in g:
                k = idx[id(w)]
                words_out.append(dict(text=corr.get(str(k), w[2].strip()), t0=t + (w[0] - s) / velocidad,
                                      t1=t + (w[1] - s) / velocidad, toma=ti, idx=k, orig=w[2].strip()))
            t += (e - s) / velocidad
            piezas[-1]["out_e"] = t
        tomas_out.append((t_ini, t))
    return piezas, words_out, tomas_out
