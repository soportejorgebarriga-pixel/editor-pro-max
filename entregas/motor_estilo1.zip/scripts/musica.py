"""Música sintetizada con código (sin bibliotecas de stock): cama de tensión para ganchos y preguntas.
Pulso grave en corcheas, tic de reloj en cada tiempo, dron que crece, motivo de segunda menor y
un ascenso (riser) que llega a la pregunta. Termina en seco con una cola corta para dar impacto."""
import numpy as np
from scipy.signal import butter, sosfilt

SR = 48000


def _lp(x, f, o=2):
    return sosfilt(butter(o, f, "low", fs=SR, output="sos"), x)


def _bp(x, lo, hi, o=2):
    return sosfilt(butter(o, [lo, hi], "band", fs=SR, output="sos"), x)


def _nota(f, dur, a=0.004, r=0.18, forma="tri"):
    n = int(dur * SR); t = np.arange(n) / SR
    ph = 2 * np.pi * f * t
    w = (2 / np.pi) * np.arcsin(np.sin(ph)) if forma == "tri" else np.sin(ph)
    return w * np.minimum(1, t / a) * np.exp(-t / r)


def tension(dur, bpm=96, riser=2.6, cola=0.5, seed=3):
    """dur: segundos de música antes del corte; riser: segundos del ascenso final."""
    rng = np.random.default_rng(seed)
    n = int((dur + cola) * SR)
    t = np.arange(n) / SR
    out = np.zeros(n)
    beat = 60 / bpm
    crece = np.clip(t / max(dur, 0.1), 0, 1)
    # 1) dron grave (La + Mi), filtrado, que crece
    dr = 0.55 * np.sin(2 * np.pi * 55 * t) + 0.35 * np.sin(2 * np.pi * 82.41 * t) + 0.15 * np.sin(2 * np.pi * 110 * t + np.sin(2 * np.pi * .3 * t))
    out += _lp(dr, 300) * (0.35 + 0.45 * crece) * np.minimum(1, t / 0.6)
    # 2) pulso en corcheas (La1), acento en el tiempo
    k = 0
    while k * beat / 2 < dur:
        s = int(k * beat / 2 * SR)
        nt = _nota(55 if (k // 8) % 2 == 0 else 58.27, 0.22, r=0.07, forma="sin") * (1.0 if k % 2 == 0 else 0.6)
        m = min(len(nt), n - s); out[s:s + m] += 0.9 * nt[:m]
        k += 1
    # 3) tic de reloj en cada tiempo
    k = 0
    while k * beat < dur:
        s = int(k * beat * SR)
        tk = _bp(rng.standard_normal(int(0.03 * SR)), 3500, 9000) * np.exp(-np.arange(int(0.03 * SR)) / SR / 0.006)
        m = min(len(tk), n - s); out[s:s + m] += 0.35 * tk[:m]
        k += 1
    # 4) motivo de segunda menor (La3 -> Sib3) cada compás
    k = 0
    while k * 4 * beat < dur:
        for j, f in enumerate((220.0, 233.08, 220.0, 207.65)):
            s = int((k * 4 + j) * beat * SR + 0.5 * beat * SR)
            if s / SR > dur - 0.2: break
            nt = _nota(f, 0.5, r=0.22) * 0.32 * (0.6 + 0.4 * min(1, k / 3))
            m = min(len(nt), n - s); out[s:s + m] += nt[:m]
        k += 1
    # 5) riser: ruido filtrado que sube + seno ascendente
    a = max(0, dur - riser)
    sel = (t >= a) & (t < dur)
    tr = (t[sel] - a) / riser
    nz = rng.standard_normal(sel.sum())
    rz = np.zeros(sel.sum())
    for q in range(8):   # barrido por bloques
        i0, i1 = int(q * len(rz) / 8), int((q + 1) * len(rz) / 8)
        lo = 400 + 5000 * q / 8
        rz[i0:i1] = _bp(nz[i0:i1], lo, lo * 2.2)
    f = 220 * 2 ** (tr * 1.5)
    sw = np.sin(2 * np.pi * np.cumsum(f) / SR)
    out[sel] += (0.35 * rz + 0.18 * sw) * tr ** 2
    # corte en seco + cola corta
    env = np.ones(n); i = int(dur * SR)
    env[i:] = np.exp(-(np.arange(n - i) / SR) / (cola / 4))
    out *= env
    return (out / (np.abs(out).max() + 1e-9) * 0.9).astype(np.float32)
