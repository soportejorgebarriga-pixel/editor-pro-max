"""Ilustraciones animadas en estilo línea (trazos que se dibujan solos), hechas con código.
Trazo blanco cálido para estructuras, verde marca para el dinero. Sin rebotes ni sacudidas.
Cada escena: fn(canvas, t, tw, anclas) — tw(spec) da el tiempo absoluto de una palabra/ancla."""
import math
from PIL import Image, ImageDraw
from config import *
import animaciones as A

SS = 2                  # supermuestreo para trazos suaves
Y0, Y1 = 230, 1270      # franja que se dibuja (zona segura)
TRAZO = 6


class Capa:
    def __init__(self):
        self.im = Image.new("RGBA", (W * SS, (Y1 - Y0) * SS), (0, 0, 0, 0))
        self.d = ImageDraw.Draw(self.im)
        self.cajas = []

    def P(self, pts):
        return [(x * SS, (y - Y0) * SS) for x, y in pts]

    def linea(self, pts, p, col=BLANCO, w=TRAZO, alpha=255):
        if p <= 0 or len(pts) < 2:
            return
        q = self.P(pts)
        segs = [math.dist(q[i], q[i + 1]) for i in range(len(q) - 1)]
        L = sum(segs) * min(p, 1.0)
        out = [q[0]]
        for i, s in enumerate(segs):
            if L >= s:
                out.append(q[i + 1]); L -= s
            else:
                k = L / s if s else 0
                a, b = q[i], q[i + 1]
                out.append((a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k))
                break
        c = col + (int(alpha),)
        self.d.line(out, fill=c, width=w * SS, joint="curve")
        r = w * SS / 2
        for e in (out[0], out[-1]):
            self.d.ellipse([e[0] - r, e[1] - r, e[0] + r, e[1] + r], fill=c)

    def secuencia(self, paths, p, **kw):
        """Dibuja varios trazos en orden, repartiendo el avance por longitud."""
        ls = [sum(math.dist(pp[i], pp[i + 1]) for i in range(len(pp) - 1)) for pp in paths]
        tot = sum(ls) or 1
        L = tot * max(0, min(1, p))
        for pp, l in zip(paths, ls):
            if L <= 0:
                break
            self.linea(pp, min(1, L / l) if l else 1, **kw)
            L -= l

    def relleno(self, pts, col, alpha):
        self.d.polygon(self.P(pts), fill=col + (int(alpha),))

    def texto(self, txt, x, y, size, font=ANTON, col=BLANCO, p=1.0, centro=True):
        if p <= 0:
            return
        im = A.linea(((txt, col),), size * SS, font)
        xx = x * SS - (im.width / 2 if centro else 0)
        off = int((1 - p) * im.height)
        if off < im.height:
            self.im.alpha_composite(im.crop((0, 0, im.width, im.height - off)), (int(xx), int((y - Y0) * SS + off)))
        self.cajas.append((txt, (xx) / SS, y, (xx + im.width) / SS, y + im.height / SS))

    def pegar(self, canvas):
        canvas.alpha_composite(self.im.resize((W, Y1 - Y0), Image.LANCZOS), (0, Y0))


# ---------- formas ----------
def circ(cx, cy, r, n=44, a0=-90, rx=None, ry=None):
    rx = rx or r; ry = ry or r
    return [(cx + rx * math.cos(math.radians(a0 + 360 * k / n)), cy + ry * math.sin(math.radians(a0 + 360 * k / n))) for k in range(n + 1)]


def rect(x0, y0, x1, y1):
    return [(x0, y0), (x1, y0), (x1, y1), (x0, y1), (x0, y0)]


def tienda(c, cx, base, w, h, p, letra):
    x0, x1 = cx - w / 2, cx + w / 2
    top = base - h
    paths = [[(x0 - 18, base), (x1 + 18, base)], rect(x0, top, x1, base),
             rect(cx - w * .13, base - h * .58, cx + w * .13, base),
             rect(x0 + w * .08, top + h * .30, cx - w * .22, top + h * .62),
             rect(cx + w * .22, top + h * .30, x1 - w * .08, top + h * .62),
             rect(x0 - 14, top - 54, x1 + 14, top)]
    n = 5
    sc = []
    for k in range(n):                       # festón del toldo
        a = x0 - 14 + (w + 28) * k / n; b = x0 - 14 + (w + 28) * (k + 1) / n
        sc += [(a + (b - a) * (1 - math.cos(math.pi * j / 10)) / 2, top + math.sin(math.pi * j / 10) * 26) for j in range(11)]
    paths.append(sc)
    paths.append(rect(cx - w * .33, top - 140, cx + w * .33, top - 70))
    paths.append([(cx - w * .2, top - 70), (cx - w * .2, top - 54)])
    paths.append([(cx + w * .2, top - 70), (cx + w * .2, top - 54)])
    if p > 0.55:   # rayas verdes del toldo
        for k in range(0, n, 2):
            a = x0 - 14 + (w + 28) * k / n; b = x0 - 14 + (w + 28) * (k + 1) / n
            c.relleno([(a, top - 54), (b, top - 54), (b, top), (a, top)], VERDE, 150 * min(1, (p - .55) / .3))
    c.secuencia(paths, p)
    c.texto(letra, cx, top - 150, 66, col=VERDE, p=A.ease((p - .8) / .2))
    c.cajas.append(("tienda" + letra, x0 - 18, top - 140, x1 + 18, base))


def moneda(c, cx, cy, rx=70, ry=18, alpha=255, col=VERDE, grosor=16):
    """Moneda de canto (elipse + costado) con relleno que tapa la de abajo."""
    top = circ(cx, cy, 0, 40, 0, rx, ry)
    arriba = [(cx + rx * math.cos(math.radians(g)), cy + ry * math.sin(math.radians(g))) for g in range(180, 361, 10)]
    abajo = [(cx + rx * math.cos(math.radians(g)), cy + grosor + ry * math.sin(math.radians(g))) for g in range(0, 181, 10)]
    c.relleno(arriba + abajo, AZUL, alpha)
    c.linea(top, 1, col=col, alpha=alpha, w=5)
    c.linea([(cx + rx * math.cos(math.radians(a)), cy + grosor + ry * math.sin(math.radians(a))) for a in range(0, 181, 10)], 1, col=col, alpha=alpha, w=5)
    c.linea([(cx - rx, cy), (cx - rx, cy + grosor)], 1, col=col, alpha=alpha, w=5)
    c.linea([(cx + rx, cy), (cx + rx, cy + grosor)], 1, col=col, alpha=alpha, w=5)
    c.linea(circ(cx, cy, 0, 30, 0, rx * .55, ry * .55), 1, col=col, alpha=alpha * .7, w=3)


def pila(c, cx, base, n_total, t, t0, alpha=255, paso=0.14):
    """Monedas que caen una a una y se apilan."""
    for k in range(n_total):
        pk = A.prog(t, t0 + k * paso, 0.28)
        if pk <= 0:
            break
        y = base - k * 24 - (1 - pk) * 90
        moneda(c, cx, y, alpha=alpha * min(1, pk * 2))
    c.cajas.append(("pila", cx - 70, base - n_total * 24 - 20, cx + 70, base + 36))


def calendario(c, cx, cy, p, numero, s=118):
    x0, y0, x1, y1 = cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2
    c.secuencia([rect(x0, y0, x1, y1), [(x0, y0 + 30), (x1, y0 + 30)],
                 [(x0 + 28, y0 - 14), (x0 + 28, y0 + 12)], [(x1 - 28, y0 - 14), (x1 - 28, y0 + 12)]], p)
    if p > .6:
        c.relleno([(x0, y0), (x1, y0), (x1, y0 + 30), (x0, y0 + 30)], VERDE, 200 * min(1, (p - .6) / .3))
        c.texto(str(numero), cx, y0 + 26, 64, p=1)


def billete(c, x, y, a=1.0, w=118, h=62):
    c.relleno(rect(x - w / 2, y - h / 2, x + w / 2, y + h / 2)[:4], AZUL, 255 * a)
    c.linea(rect(x - w / 2, y - h / 2, x + w / 2, y + h / 2), 1, col=VERDE, alpha=255 * a, w=5)
    c.linea(circ(x, y, 16), 1, col=VERDE, alpha=255 * a, w=4)
    c.linea(rect(x - w / 2 + 12, y - h / 2 + 10, x + w / 2 - 12, y + h / 2 - 10), 1, col=VERDE, alpha=110 * a, w=2)


def palomita(c, x, y, s, p):
    c.linea([(x, y + s * .55), (x + s * .38, y + s * .9), (x + s, y + s * .1)], p, col=VERDE, w=8)


def reloj(c, cx, cy, r, t, t0, p):
    c.linea(circ(cx, cy, r), p)
    if p > .7:
        ang = (t - t0) * 360 * 0.9
        c.linea([(cx, cy), (cx + r * .7 * math.cos(math.radians(ang - 90)), cy + r * .7 * math.sin(math.radians(ang - 90)))], 1, col=VERDE, w=5)
        c.linea([(cx, cy), (cx, cy - r * .45)], 1, w=5)


def caja_fuerte(c, cx, cy, s, p, abierta=0.0):
    x0, y0, x1, y1 = cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2
    c.secuencia([rect(x0, y0, x1, y1), [(x0 + 30, y1), (x0 + 30, y1 + 22)], [(x1 - 30, y1), (x1 - 30, y1 + 22)]], p)
    if p < .5:
        return
    q = A.ease((p - .5) / .5)
    m = 22
    if abierta <= 0:
        c.linea(rect(x0 + m, y0 + m, x1 - m, y1 - m), q)
        c.linea(circ(cx + s * .12, cy, s * .14), q)
        c.linea([(cx + s * .12, cy - s * .14), (cx + s * .12, cy - s * .2)], q, w=5)
        c.linea([(x1 - m - 18, cy - 30), (x1 - m - 18, cy + 30)], q, w=8)
    else:
        # la puerta gira hacia la izquierda (paralelogramo), adentro: vacío
        c.relleno(rect(x0 + m, y0 + m, x1 - m, y1 - m)[:4], (8, 22, 32), 255)
        c.linea(rect(x0 + m, y0 + m, x1 - m, y1 - m), 1, alpha=120, w=3)
        dx = (s - 2 * m) * (1 - 1.55 * abierta)
        sk = 34 * abierta
        door = [(x0 + m, y0 + m), (x0 + m + dx, y0 + m - sk), (x0 + m + dx, y1 - m + sk), (x0 + m, y1 - m), (x0 + m, y0 + m)]
        c.relleno(door[:4], AZUL, 255)
        c.linea(door, 1)


# ---------- escenas ----------
def tiendas(canvas, t, tw, an):
    """Negocio A vs Negocio B: tienda, venta, utilidad (monedas) y forma de cobro."""
    c = Capa()
    cols = [("A", 265, an["A"], an["ventaA"], an["utilA"], an["cobroA"], 4),
            ("B", 685, an["B"], an["ventaB"], an["utilB"], an["cobroB"], 3)]
    for letra, cx, tA, tV, tU, tC, n in cols:
        tA, tV, tU, tC = tw(tA), tw(tV), tw(tU), tw(tC)
        if t < tA - 0.01:
            continue
        tienda(c, cx, 700, 320, 270, A.prog(t, tA, 1.0), letra)
        c.texto("$100,000", cx, 712, 80, p=A.prog(t, tV, .3))
        c.texto("vende al mes", cx, 808, 38, font=DMSANS, col=(200, 210, 214), p=A.prog(t, tV + .1, .3))
        if t >= tU:
            pend = letra == "A" and t > tC + 0.5
            alpha = 255 - 150 * A.prog(t, tC + 0.5, .4) if letra == "A" else 255
            pila(c, cx - 95, 1010, n, t, tU, alpha=alpha)
            c.texto("$40,000" if letra == "A" else "$30,000", cx + 82, 898, 56, p=A.prog(t, tU + .25, .3))
            c.texto("utilidad", cx + 82, 966, 36, font=DMSANS, col=(200, 210, 214), p=A.prog(t, tU + .35, .3))
        if t >= tC:
            pc = A.prog(t, tC, .5)
            if letra == "A":
                calendario(c, cx - 100, 1160, pc, A.contador(90, A.prog(t, tC + .3, 1.1)) or 1)
                c.texto("Te pagan", cx + 73, 1092, 36, font=DMSANS, col=(200, 210, 214), p=A.prog(t, tC + .2, .3))
                c.texto("a 90 días", cx + 73, 1136, 42, font=DMSANS_B, p=A.prog(t, tC + .3, .3))
            else:
                for k in range(3):   # billetes que caen al momento
                    pk = A.prog(t, tC + k * .12, .35)
                    if pk > 0:
                        billete(c, cx - 100 + (k - 1) * 10, 1110 + k * 26 - (1 - pk) * 120, a=pk)
                palomita(c, cx - 150, 1185, 48, A.prog(t, tC + .5, .3))
                c.texto("Te pagan", cx + 73, 1092, 36, font=DMSANS, col=(200, 210, 214), p=A.prog(t, tC + .2, .3))
                c.texto("de contado", cx + 73, 1136, 42, font=DMSANS_B, p=A.prog(t, tC + .3, .3))
    c.pegar(canvas)
    return c.cajas


def _arco(a, b, alto, k):
    x = a[0] + (b[0] - a[0]) * k
    y = a[1] + (b[1] - a[1]) * k - alto * math.sin(math.pi * k)
    return x, y


def puente(canvas, t, tw, an):
    """Tu capital sostiene el negocio mientras llegan los 90 días."""
    c = Capa()
    t0, t90 = tw(an["inicio"]), tw(an["dia90"])
    c.texto("TU CAPITAL", 235, 330, 64, p=A.prog(t, t0, .3))
    caja_fuerte(c, 235, 620, 280, A.prog(t, t0, .8))
    tienda(c, 690, 760, 300, 260, A.prog(t, t0 + .15, .9), "A")
    # monedas que viajan de la caja a la tienda
    if t > t0 + .6:
        for k in range(6):
            ph = ((t - t0 - .6) * 0.9 + k / 6) % 1
            x, y = _arco((330, 600), (585, 720), 250, ph)
            c.linea(circ(x, y, 28), 1, col=VERDE, w=6)
            c.linea(circ(x, y, 12), 1, col=VERDE, w=3, alpha=160)
    # línea de tiempo HOY -> DÍA 90
    yl = 1070
    pl = A.prog(t, t0 + .3, .5)
    c.linea([(110, yl), (850, yl)], pl)
    for k in range(4):
        x = 110 + 740 * k / 3
        c.linea([(x, yl - 14), (x, yl + 14)], pl)
    c.texto("HOY", 120, yl + 30, 46, font=DMSANS_B, p=pl)
    c.texto("DÍA 90", 800, yl + 30, 46, font=DMSANS_B, p=pl)
    prog_dia = A.prog(t, t0 + .5, max(.6, t90 - t0 - .3))
    xd = 110 + 740 * prog_dia
    c.relleno(circ(xd, yl, 16)[:-1], VERDE, 255)
    if t >= t90:
        c.texto("+$40,000", 690, 800, 84, col=VERDE, p=A.prog(t, t90 + .1, .3))
    c.pegar(canvas)
    return c.cajas


def sincapital(canvas, t, tw, an):
    """Caja fuerte que se abre vacía: $0 ahorrado."""
    c = Capa()
    t0, ta, tz = tw(an["inicio"]), tw(an["abre"]), tw(an["cero"])
    c.texto("CAPITAL AHORRADO", 480, 300, 64, p=A.prog(t, t0, .3))
    ab = A.prog(t, ta, .5)
    caja_fuerte(c, 480, 720, 400, A.prog(t, t0 + .1, .8), abierta=ab)
    if t >= tz:
        c.texto("$0", 480, 640, 130, p=A.prog(t, tz, .3))
    c.pegar(canvas)
    return c.cajas


def flujo(canvas, t, tw, an):
    """Monedas que fluyen sin parar por un tubo hacia la tienda B: flujo de efectivo."""
    c = Capa()
    t0, tt = tw(an["inicio"]), tw(an["titulo"])
    c.texto("FLUJO DE", 480, 300, 104, p=A.prog(t, tt, .3))
    c.texto("EFECTIVO", 480, 410, 104, p=A.prog(t, tt + .12, .3))
    tienda(c, 690, 1000, 320, 280, A.prog(t, t0, .8), "B")
    yp = 920
    pt = A.prog(t, t0 + .1, .6)
    c.linea([(60, yp - 56), (540, yp - 56)], pt)
    c.linea([(60, yp + 56), (540, yp + 56)], pt)
    if pt >= 1:
        for k in range(6):
            x = 90 + ((t - t0) * 420 + k * 100) % 480
            c.linea(circ(x, yp, 32), 1, col=VERDE, w=6)
            c.linea(circ(x, yp, 14), 1, col=VERDE, w=3, alpha=160)
    c.pegar(canvas)
    return c.cajas


ESCENAS = {"tiendas": tiendas, "puente": puente, "sincapital": sincapital, "flujo": flujo}
