"""Piezas de motion graphics del Estilo 1 (PIL). Curva: arranque rápido, frenado suave. Sin rebotes."""
from functools import lru_cache
from PIL import Image, ImageDraw, ImageFilter, ImageFont
from config import *


def ease(x):
    x = max(0.0, min(1.0, x))
    return 1 - (1 - x) ** 4


def prog(t, t0, dur):
    return ease((t - t0) / dur) if dur > 0 else float(t >= t0)


@lru_cache(None)
def font(path, size):
    return ImageFont.truetype(path, size)


def ancho(texto, path, size):
    return font(path, size).getlength(texto)


# ---------- texto ----------
@lru_cache(512)
def linea(partes, size, path=ANTON):
    """partes: tuple de (texto, rgb). Devuelve RGBA ajustado al alto de la fuente."""
    f = font(path, size)
    asc, desc = f.getmetrics()
    w = int(sum(f.getlength(p[0]) for p in partes)) + 4
    im = Image.new("RGBA", (w, asc + desc), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    x = 0
    for txt, col in partes:
        d.text((x, 0), txt, font=f, fill=col + (255,))
        x += f.getlength(txt)
    return im


def subir(canvas, im, x, y, p):
    """Texto que sale de detrás de una línea invisible (su borde inferior)."""
    if p <= 0:
        return
    h = im.height
    off = int(round((1 - p) * h))
    if off >= h:
        return
    canvas.alpha_composite(im.crop((0, 0, im.width, h - off)), (int(x), int(y + off)))


def titulo(canvas, t, t0, lineas, y, size=T_TITULO, x=None, oro=None, t_oro=None, barra=True,
           stagger=0.16, dur=0.32, lh=1.02):
    """lineas: lista de str. oro: palabra (en mayúsculas) a encender en dorado en t_oro."""
    yy = y
    maxw = 0
    for i, ln in enumerate(lineas):
        partes = []
        if oro and oro in ln:
            a, b = ln.split(oro, 1)
            on = t_oro is not None and t >= t_oro
            if t_oro is not None and t_oro <= t < t_oro + 0.12:
                k = (t - t_oro) / 0.12
                col = tuple(int(BLANCO[c] + (DORADO[c] - BLANCO[c]) * k) for c in range(3))
            else:
                col = DORADO if (on or t_oro is None) else BLANCO
            partes = [(a, BLANCO), (oro, col), (b, BLANCO)]
            partes = tuple(p for p in partes if p[0])
        else:
            partes = ((ln, BLANCO),)
        im = linea(partes, size)
        xx = x if x is not None else SUB_X - im.width / 2
        subir(canvas, im, xx, yy, prog(t, t0 + i * stagger, dur))
        maxw = max(maxw, im.width)
        yy += int(size * lh)
    if barra:
        pb = prog(t, t0 + len(lineas) * stagger, 0.35)
        if pb > 0:
            bw = int(min(maxw, 420) * pb)
            bx = (x if x is not None else SUB_X - min(maxw, 420) / 2)
            ImageDraw.Draw(canvas).rounded_rectangle([bx, yy + 12, bx + bw, yy + 24], 6, fill=VERDE + (255,))
    return yy + 24


# ---------- tarjetas ----------
def vidrio(canvas, fondo_rgb, box, radio=28, alpha=150):
    """Tarjeta de vidrio esmerilado: fondo desenfocado + azul noche + borde fino."""
    x0, y0, x1, y1 = [int(v) for v in box]
    if x1 - x0 < 4 or y1 - y0 < 4:
        return
    crop = fondo_rgb.crop((x0, y0, x1, y1)).filter(ImageFilter.GaussianBlur(22)).convert("RGBA")
    crop.alpha_composite(Image.new("RGBA", crop.size, AZUL + (alpha,)))
    mask = Image.new("L", crop.size, 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, x1 - x0 - 1, y1 - y0 - 1], radio, fill=255)
    canvas.paste(crop, (x0, y0), mask)
    ImageDraw.Draw(canvas).rounded_rectangle([x0, y0, x1 - 1, y1 - 1], radio, outline=(255, 255, 255, 70), width=2)


def palomita(d, x, y, s, p, col=VERDE, w=7):
    pts = [(x, y + s * .55), (x + s * .38, y + s * .9), (x + s, y + s * .1)]
    l1 = ((pts[1][0] - pts[0][0]) ** 2 + (pts[1][1] - pts[0][1]) ** 2) ** .5
    l2 = ((pts[2][0] - pts[1][0]) ** 2 + (pts[2][1] - pts[1][1]) ** 2) ** .5
    L = (l1 + l2) * p
    if L <= 0:
        return
    if L <= l1:
        k = L / l1
        d.line([pts[0], (pts[0][0] + (pts[1][0] - pts[0][0]) * k, pts[0][1] + (pts[1][1] - pts[0][1]) * k)], fill=col + (255,), width=w, joint="curve")
    else:
        k = (L - l1) / l2
        d.line([pts[0], pts[1], (pts[1][0] + (pts[2][0] - pts[1][0]) * k, pts[1][1] + (pts[2][1] - pts[1][1]) * k)], fill=col + (255,), width=w, joint="curve")


def lista(canvas, fondo, t, items, x0, y0, ancho_card=780, size=T_LISTA, titulo_txt=None):
    """items: lista de (texto, t_aparece). La tarjeta crece con cada punto; palomita se dibuja sola."""
    pad, gap = 40, int(size * 1.45)
    top = 0
    if titulo_txt:
        top = 64
    vis = [it for it in items if t >= it[1]]
    if not vis:
        return None
    # alto animado
    h_obj = pad * 2 + top + gap * len(vis) - (gap - size) + 8
    h_prev = pad * 2 + top + gap * (len(vis) - 1) - (gap - size) + 8 if len(vis) > 1 else 0
    h = h_prev + (h_obj - h_prev) * prog(t, vis[-1][1], 0.25)
    if len(vis) == 1:
        h = h_obj * prog(t, vis[0][1], 0.25)
    box = (x0, y0, x0 + ancho_card, y0 + h)
    vidrio(canvas, fondo, box)
    d = ImageDraw.Draw(canvas)
    if titulo_txt and h > pad + 40:
        im = linea(((titulo_txt, VERDE),), T_ETIQ, DMSANS_B)
        canvas.alpha_composite(im, (x0 + pad, y0 + pad - 6))
    for i, (txt, ta) in enumerate(vis):
        yy = y0 + pad + top + i * gap
        if yy + size > y0 + h:
            break
        palomita(d, x0 + pad, yy + 6, size * 0.8, prog(t, ta + 0.08, 0.3))
        im = linea(((txt, BLANCO),), size)
        subir(canvas, im, x0 + pad + size * 1.1, yy - size * 0.18, prog(t, ta + 0.05, 0.3))
    return box


def pastilla(canvas, t, t0, texto, cx, y, size=54, flecha=True, direccion="abajo"):
    p = prog(t, t0, 0.3)
    if p <= 0:
        return
    im = linea(((texto, BLANCO),), size, DMSANS_B)
    w, h = im.width + 80, size + 44
    s = 0.85 + 0.15 * p
    pill = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ImageDraw.Draw(pill).rounded_rectangle([0, 0, w - 1, h - 1], h // 2, fill=VERDE + (255,))
    pill.alpha_composite(im, (40, (h - im.height) // 2 - 2))
    pill = pill.resize((int(w * s), int(h * s)), Image.LANCZOS)
    a = pill.getchannel("A").point(lambda v: int(v * p))
    pill.putalpha(a)
    canvas.alpha_composite(pill, (int(cx - pill.width / 2), int(y + (h - pill.height) / 2)))
    if flecha and direccion == "derecha":
        # flecha hacia el botón de comentarios (columna derecha), sin pasar de x = 880
        import math
        pa = prog(t, t0 + 0.25, 0.3)
        dx = 8 * math.sin(max(0, t - t0 - 0.55) * 5) if pa >= 1 else 0
        d = ImageDraw.Draw(canvas)
        x1 = cx + w * s / 2 + 18 + dx
        x2 = min(x1 + 90 * pa, Z_RIGHT - 14)
        yy = y + h / 2
        if pa > 0:
            d.line([(x1, yy), (x2, yy)], fill=BLANCO + (255,), width=8)
            if pa > 0.6:
                d.polygon([(x2 - 4, yy - 22), (x2 - 4, yy + 22), (x2 + 14, yy)], fill=BLANCO + (255,))
        return
    if flecha:
        pa = prog(t, t0 + 0.25, 0.3)
        # flecha que baja hacia el botón del anuncio (con vaivén suave, sin rebote)
        import math
        dy = 10 * math.sin(max(0, t - t0 - 0.55) * 5) if pa >= 1 else 0
        d = ImageDraw.Draw(canvas)
        x = cx
        y1 = y + h + 22 + dy
        y2 = y1 + 70 * pa
        if pa > 0:
            d.line([(x, y1), (x, y2)], fill=BLANCO + (255,), width=8)
            if pa > 0.6:
                d.polygon([(x - 24, y2 - 20), (x + 24, y2 - 20), (x, y2 + 12)], fill=BLANCO + (255,))


def contador(valor, p):
    return int(round(valor * p))


def comparacion(canvas, fondo, t, cols, y, alto_fila=205, resalta=None, t_resalta=None):
    """Tarjetas lado a lado (A | B). cols: [{titulo, t, filas: [(etiqueta, valor, t)]}].
    La tarjeta crece con cada fila; al elegir, la columna elegida se enmarca en verde y la otra se apaga."""
    xs = [(60, 455), (475, 870)]
    head = 132
    cajas = []
    for ci, col in enumerate(cols):
        if t < col["t"]:
            continue
        x0, x1 = xs[ci]
        vis = [f for f in col["filas"] if t >= f[2]]
        h_obj = head + alto_fila * len(vis) + 24
        h_prev = head + alto_fila * max(0, len(vis) - 1) + 24
        tref = vis[-1][2] if vis else col["t"]
        h = h_prev + (h_obj - h_prev) * prog(t, tref, 0.25) if vis else head * prog(t, col["t"], 0.25)
        vidrio(canvas, fondo, (x0, y, x1, y + h))
        d = ImageDraw.Draw(canvas)
        ph = prog(t, col["t"], 0.3)
        if ph > 0 and h > 60:
            d.rounded_rectangle([x0 + 22, y + 22, x0 + 22 + (x1 - x0 - 44) * ph, y + head - 22], 18, fill=VERDE + (255,))
            im = linea(((col["titulo"], BLANCO),), 76)
            subir(canvas, im, (x0 + x1) / 2 - im.width / 2, y + 22 + (head - 44 - im.height) / 2 + 4, ph)
        for fi, (et, val, tf) in enumerate(vis):
            yy = y + head + fi * alto_fila + 10
            pf = prog(t, tf, 0.3)
            l1 = linea(((et, (200, 210, 214)),), 44, DMSANS)
            subir(canvas, l1, x0 + 32, yy, pf)
            l2 = linea(((val, BLANCO),), 92)
            subir(canvas, l2, x0 + 32, yy + 52, prog(t, tf + 0.06, 0.3))
        cajas.append((x0, y, x1, y + h))
        if resalta is not None and t_resalta is not None and t >= t_resalta:
            pr = prog(t, t_resalta, 0.3)
            if ci == resalta:
                d.rounded_rectangle([x0 - 3, y - 3, x1 + 3, y + h + 3], 30, outline=VERDE + (int(255 * pr),), width=8)
            else:
                ov = Image.new("RGBA", (x1 - x0, int(h)), AZUL + (int(150 * pr),))
                m = Image.new("L", ov.size, 0)
                ImageDraw.Draw(m).rounded_rectangle([0, 0, ov.width - 1, ov.height - 1], 28, fill=255)
                canvas.paste(Image.alpha_composite(canvas.crop((x0, y, x1, y + int(h))), ov), (x0, y), m)
    return cajas
