"""Voz editada, efectos sintetizados, mezcla con atenuación y normalización a -14 LUFS."""
import json, subprocess
import numpy as np
from scipy.signal import butter, sosfilt
from config import LUFS, TP

SR = 48000


def voz(piezas, ficha, velocidad, out_wav, extra_cola=0.0):
    clips = list(ficha["clips"])
    args = ["ffmpeg", "-v", "error", "-y"]
    for c in clips:   # voz limpia (DeepFilterNet) si existe; si no, el audio del clip
        args += ["-i", ficha.get("audio_limpio", {}).get(c, ficha["clips"][c])]
    fc = []
    for i, p in enumerate(piezas):
        d = p["e"] - p["s"]
        fc.append(f"[{clips.index(p['clip'])}:a:0]atrim={p['s']}:{p['e']},asetpts=PTS-STARTPTS,"
                  f"aformat=sample_rates={SR}:channel_layouts=mono,"
                  f"afade=t=in:d=0.008,afade=t=out:st={d - 0.015:.3f}:d=0.015[a{i}]")
    fc.append("".join(f"[a{i}]" for i in range(len(piezas))) + f"concat=n={len(piezas)}:v=0:a=1,"
              f"atempo={velocidad},highpass=f=80" + (",afftdn=nf=-25" if ficha.get("viento") else "") +
              (",equalizer=f=250:t=q:w=1.2:g=-2,equalizer=f=3500:t=q:w=1.4:g=1.5,deesser=i=0.35:f=0.5,"
               "acompressor=threshold=-22dB:ratio=2.2:attack=10:release=150:makeup=1.5" if ficha.get("voz_estudio") else "") +
              f",apad=pad_dur={extra_cola}[out]")
    subprocess.run(args + ["-filter_complex", ";".join(fc), "-map", "[out]", "-ar", str(SR), "-ac", "1", out_wav], check=True)


def _env(n, a=0.002, r=0.1):
    t = np.arange(n) / SR
    return np.minimum(1, t / a) * np.exp(-t / r)


def _band(x, lo, hi):
    return sosfilt(butter(2, [lo, hi], "band", fs=SR, output="sos"), x)


def efecto(tipo):
    rng = np.random.default_rng(len(tipo))
    if tipo == "barrido":
        n = int(0.38 * SR); t = np.arange(n) / SR
        x = _band(rng.standard_normal(n), 400, 6000)
        env = np.sin(np.pi * np.clip(t / 0.38, 0, 1)) ** 2
        return x * env * 0.5
    if tipo == "pop":
        n = int(0.09 * SR); t = np.arange(n) / SR
        f = 700 + 500 * np.exp(-t / 0.02)
        return np.sin(2 * np.pi * np.cumsum(f) / SR) * _env(n, 0.001, 0.025)
    if tipo == "golpe":
        n = int(0.5 * SR); t = np.arange(n) / SR
        f = 48 + 60 * np.exp(-t / 0.04)
        x = np.sin(2 * np.pi * np.cumsum(f) / SR) * _env(n, 0.002, 0.16)
        return x + 0.15 * _band(rng.standard_normal(n), 2000, 8000) * _env(n, 0.001, 0.01)
    if tipo == "tic":
        n = int(0.03 * SR)
        return np.sin(2 * np.pi * 2400 * np.arange(n) / SR) * _env(n, 0.0005, 0.006)
    if tipo == "camara":
        n = int(0.12 * SR)
        x = _band(rng.standard_normal(n), 1500, 9000)
        e = _env(n, 0.0005, 0.008); e2 = np.roll(_env(n, 0.0005, 0.012), int(0.06 * SR)); e2[:int(0.06 * SR)] = 0
        return x * (e + e2)
    raise ValueError(tipo)


def mezclar(voz_wav, eventos, dur, out_wav, tmp, ambiente=0.02, sfx=1.0, musica=None, musica_db=-20.0):
    """eventos: lista (tipo, t). Efectos ~8 dB por debajo de la voz y atenuados mientras habla."""
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", voz_wav, "-f", "f32le", "-ac", "1", "-ar", str(SR), "-"],
                         capture_output=True, check=True).stdout
    v = np.frombuffer(raw, np.float32).copy()
    n = int(dur * SR)
    v = np.pad(v, (0, max(0, n - len(v))))[:n]
    act = v[np.abs(v) > 0.01]
    v_rms = np.sqrt((act ** 2).mean()) if len(act) else 0.05
    fx = np.zeros(n, np.float32)
    for tipo, t in eventos:
        e = efecto(tipo)
        e = e / (np.sqrt((e[np.abs(e) > 1e-4] ** 2).mean()) + 1e-9)
        nivel = {"golpe": 0.40, "barrido": 0.30, "pop": 0.28, "tic": 0.22, "camara": 0.30}[tipo]
        e = e * v_rms * nivel * sfx
        i = int(t * SR)
        if i >= n: continue
        m = min(len(e), n - i)
        fx[i:i + m] += e[:m]
    # ambiente muy bajo para no dejar silencios muertos
    rng = np.random.default_rng(7)
    pink = sosfilt(butter(1, 800, "low", fs=SR, output="sos"), rng.standard_normal(n)) * v_rms * ambiente
    np.save(tmp + "/fx.npy", fx)
    for name, arr in (("v", v), ("fx", fx + pink)):
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", "-",
                        f"{tmp}/{name}.wav"], input=arr.astype(np.float32).tobytes(), check=True)
    entradas = ["-i", f"{tmp}/v.wav", "-i", f"{tmp}/fx.wav"]
    if musica is not None:
        # música a ~20 dB bajo la voz (medido en RMS) y con atenuación suave mientras habla
        mu = np.pad(musica, (0, max(0, n - len(musica))))[:n]
        mrms = np.sqrt((mu[np.abs(mu) > 1e-3] ** 2).mean()) + 1e-9
        mu = mu / mrms * v_rms * 10 ** (musica_db / 20)
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", "-",
                        f"{tmp}/mus.wav"], input=mu.astype(np.float32).tobytes(), check=True)
        entradas += ["-i", f"{tmp}/mus.wav"]
        fc = ("[0:a]asplit=3[vv][key][key2];"
              "[1:a][key]sidechaincompress=threshold=0.03:ratio=4:attack=5:release=180[fxd];"
              "[2:a][key2]sidechaincompress=threshold=0.05:ratio=2:attack=20:release=300[mud];"
              "[vv][fxd][mud]amix=inputs=3:normalize=0,aformat=channel_layouts=stereo[m]")
    else:
        fc = ("[0:a]asplit[vv][key];"
              "[1:a][key]sidechaincompress=threshold=0.03:ratio=4:attack=5:release=180[fxd];"
              "[vv][fxd]amix=inputs=2:normalize=0,aformat=channel_layouts=stereo[m]")
    subprocess.run(["ffmpeg", "-v", "error", "-y"] + entradas + [
                    "-filter_complex", fc,
                    "-map", "[m]", f"{tmp}/mix.wav"], check=True)
    # loudnorm de dos pasadas
    r = subprocess.run(["ffmpeg", "-hide_banner", "-i", f"{tmp}/mix.wav", "-af",
                        f"loudnorm=I={LUFS}:TP={TP}:LRA=9:print_format=json", "-f", "null", "-"],
                       capture_output=True, text=True).stderr
    j = json.loads(r[r.rindex("{"):r.rindex("}") + 1])
    af = (f"loudnorm=I={LUFS}:TP={TP}:LRA=9:measured_I={j['input_i']}:measured_TP={j['input_tp']}:"
          f"measured_LRA={j['input_lra']}:measured_thresh={j['input_thresh']}:offset={j['target_offset']}:linear=true")
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", f"{tmp}/mix.wav", "-af", af, "-ar", str(SR), f"{tmp}/ln.wav"], check=True)
    # ajuste fino: ganancia exacta + limitador para el pico real
    for _ in range(2):
        r = subprocess.run(["ffmpeg", "-hide_banner", "-i", f"{tmp}/ln.wav", "-af", "ebur128=peak=true", "-f", "null", "-"],
                           capture_output=True, text=True).stderr
        import re
        I = float(re.findall(r"I:\s+(-?[\d.]+) LUFS", r)[-1])
        g = LUFS - I
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", f"{tmp}/ln.wav", "-af",
                        f"volume={g:.2f}dB,aresample=192000,alimiter=limit=0.74:attack=1:release=60:level=0,aresample={SR}",
                        f"{tmp}/ln2.wav"], check=True)
        import shutil; shutil.move(f"{tmp}/ln2.wav", f"{tmp}/ln.wav")
    import shutil; shutil.copy(f"{tmp}/ln.wav", out_wav)
    return v_rms
