"""Hoja de cuadros: python hoja.py video.mp4 salida.jpg t1 t2 ..."""
import subprocess, sys
from PIL import Image, ImageDraw
v, out, ts = sys.argv[1], sys.argv[2], [float(x) for x in sys.argv[3:]]
ims = []
for t in ts:
    raw = subprocess.run(["ffmpeg", "-v", "error", "-ss", str(t), "-i", v, "-frames:v", "1", "-vf", "scale=270:480",
                          "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True).stdout
    im = Image.frombytes("RGB", (270, 480), raw)
    d = ImageDraw.Draw(im)
    for y in (60, 335): d.line([(0, y), (270, y)], fill=(255, 0, 0))
    d.line([(220, 0), (220, 480)], fill=(255, 0, 0))
    d.text((4, 4), f"{t:.1f}s", fill=(255, 255, 0))
    ims.append(im)
cols = 6
rows = (len(ims) + cols - 1) // cols
sheet = Image.new("RGB", (270 * cols, 480 * rows))
for i, im in enumerate(ims):
    sheet.paste(im, (270 * (i % cols), 480 * (i // cols)))
sheet.save(out, quality=85)
