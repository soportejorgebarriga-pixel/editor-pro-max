"""Audio -> palabras con tiempos (faster-whisper, int8)."""
import json, subprocess, sys
import numpy as np

PROMPT = ("Jorge Barriga, Arbat, Don Tazón, emprendedores, finanzas, Latinoamérica, Ecuador, "
          "Perú, Guatemala, Costa Rica, México")
_model = {}
MODELO = "large-v3"   # el más preciso; "small" si se necesita rapidez


def audio16k(path):
    """Devuelve audio mono 16 kHz float32 (elige la primera pista de audio)."""
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-map", "0:a:0", "-ac", "1",
                          "-ar", "16000", "-f", "s16le", "-"], capture_output=True, check=True).stdout
    return np.frombuffer(raw, np.int16).astype(np.float32) / 32768


def transcribir(path_or_audio, extra_prompt="", modelo=None):
    from faster_whisper import WhisperModel
    modelo = modelo or MODELO
    if modelo not in _model:
        _model[modelo] = WhisperModel(modelo, compute_type="int8")
    a = audio16k(path_or_audio) if isinstance(path_or_audio, str) else path_or_audio
    segs, _ = _model[modelo].transcribe(a, language="es", word_timestamps=True, condition_on_previous_text=False,
                                initial_prompt=PROMPT + (", " + extra_prompt if extra_prompt else ""))
    return [(round(w.start, 3), round(w.end, 3), w.word.strip()) for s in segs for w in s.words]


if __name__ == "__main__":
    out = {}
    for p in sys.argv[2:]:
        out[p] = transcribir(p)
    json.dump(out, open(sys.argv[1], "w"), ensure_ascii=False, indent=0)
