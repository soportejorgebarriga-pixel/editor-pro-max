"""Subtítulos por frase (3–6 palabras, una línea ≤760 px) en ASS con palabra clave dorada sincronizada."""
import re
from animaciones import ancho
from config import *

MULETILLAS = {"eh", "este", "mmm", "o sea", "ehh", "em"}


def _norm(w):
    return re.sub(r"[^\wáéíóúñü$%]", "", w.lower())


def _ts(t):
    t = max(0, t)
    h = int(t // 3600); m = int(t % 3600 // 60); s = t % 60
    return f"{h}:{m:02d}:{s:05.2f}"


def _w(frase, clave):
    total = 0
    for i, w in enumerate(frase):
        txt = w["txt"] + (" " if i < len(frase) - 1 else "")
        if clave is not None and i == clave:
            total += ancho(w["txt"].upper(), ANTON, T_CLAVE) + ancho(" ", DMSANS_B, T_SUB) * (i < len(frase) - 1)
        else:
            total += ancho(txt, DMSANS_B, T_SUB)
    return total


def frases(words, ficha):
    corr = ficha.get("correcciones", {})
    ocultar = ficha.get("sin_subtitulos", [])  # lista de [t0, t1]
    ws = []
    for w in words:
        if any(a <= (w["t0"] + w["t1"]) / 2 <= b for a, b in ocultar):
            continue
        txt = w["text"]
        key = _norm(txt)
        if key in MULETILLAS and not w.get("keep"):
            continue
        for k, v in corr.items():
            if _norm(k) == key:
                txt = re.sub(re.escape(k.strip("¿?,.")), v, txt, flags=re.I) if k.strip("¿?,.") else v
                break
        ws.append(dict(w, txt=txt))
    # 1) cláusulas: puntuación, cambio de toma o pausa
    claves = [_norm(c) for c in ficha.get("claves", [])]
    cl, cur = [], []
    for w in ws:
        if cur and (w["toma"] != cur[-1]["toma"] or w["t0"] - cur[-1]["t1"] > 0.6):
            cl.append(cur); cur = []
        cur.append(w)
        if re.search(r"[.?!,;:]$", w["txt"]):
            cl.append(cur); cur = []
    if cur:
        cl.append(cur)
    # 2) cláusulas de 1 palabra: unir con la vecina de la misma toma si cabe
    m = []
    for c in cl:
        if m and (len(c) == 1 or len(m[-1]) == 1) and c[0]["toma"] == m[-1][-1]["toma"]:
            m[-1] = m[-1] + c
        else:
            m.append(c)
    # 3) partir cada cláusula en frases equilibradas (≥2 palabras, ≤6, ≤ ancho)
    res = []
    for c in m:
        n = len(c)
        best = {0: (0, [])}
        for j in range(1, n + 1):
            for i in range(max(0, j - 6), j):
                if i not in best: continue
                f = c[i:j]
                if len(f) < 2 and n > 1: continue
                kk = next((q for q, w in enumerate(f) if w.get("clave")), None)
                wv = _w(f, kk)
                if wv > SUB_MAX_W: continue
                cost = best[i][0] + 1000 + (350 if len(f) < 3 else 0) + wv * 0.2
                if j not in best or cost < best[j][0]:
                    best[j] = (cost, best[i][1] + [f])
        res += best[n][1] if n in best else [c]
    # clave por frase (máximo una)
    final = []
    for f in res:
        k = None
        for j, w in enumerate(f):
            if w.get("clave") or _norm(w["txt"]) in claves:
                k = j; break
        # ancho real con la clave; si no cabe, partir
        if _w(f, k) > SUB_MAX_W:
            m = len(f) // 2
            final += [(f[:m], None), (f[m:], None)]
            for a in (f[:m], f[m:]):
                pass
            final[-2] = (f[:m], next((j for j, w in enumerate(f[:m]) if w.get("clave")), None))
            final[-1] = (f[m:], next((j for j, w in enumerate(f[m:]) if w.get("clave")), None))
        else:
            final.append((f, k))
    return final


def escribir_ass(path, words, ficha, fin_total):
    fs = frases(words, ficha)
    head = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {W}
PlayResY: {H}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Sub,DM Sans,68,&H00EEF4F7,&H00EEF4F7,&H263B2A0E,&H00000000,-1,0,0,0,100,100,0,0,3,16,0,2,80,200,590,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    lines, info = [], []
    for i, (f, k) in enumerate(fs):
        t0 = f[0]["t0"] - 0.03
        t1 = fs[i + 1][0][0]["t0"] - 0.03 if i + 1 < len(fs) else f[-1]["t1"] + 0.35
        t1 = min(t1, f[-1]["t1"] + 0.6)
        lim = [b for a, b in [(x, y) for x, y in ficha.get("sin_subtitulos", [])] if a > t0]
        if lim:
            t1 = min(t1, min(a for a, b in ficha.get("sin_subtitulos", []) if a > t0))
        txt = "{\\an2\\move(480,1346,480,1330,0,160)\\fad(90,0)\\fscx94\\fscy94\\t(0,160,\\fscx100\\fscy100)}"
        parts = []
        for j, w in enumerate(f):
            if j == k:
                ms = max(0, int((w["t0"] - t0) * 1000))
                parts.append("{\\fnAnton\\b0\\fs88\\c&H00EEF4F7&\\t(%d,%d,\\c&H004EC1F2&)}%s{\\r}" % (ms, ms + 120, w["txt"].upper()))
            else:
                parts.append(w["txt"])
        txt += " ".join(parts)
        lines.append(f"Dialogue: 0,{_ts(t0)},{_ts(t1)},Sub,,0,0,0,,{txt}")
        info.append(dict(t0=t0, t1=t1, texto=" ".join(w["txt"] for w in f), ancho=_w(f, k),
                         clave=(f[k]["txt"] if k is not None else None), t_clave=(f[k]["t0"] if k is not None else None)))
    open(path, "w").write(head + "\n".join(lines) + "\n")
    return info
