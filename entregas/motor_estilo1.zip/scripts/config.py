"""Estilo 1 — única fuente de valores (paleta, tamaños, zonas, tiempos, niveles)."""
import os

W, H, FPS = 1080, 1920, 30

# Paleta
VERDE = (0x1D, 0x9E, 0x75)
AZUL = (0x0E, 0x2A, 0x3B)
DORADO = (0xF2, 0xC1, 0x4E)
BLANCO = (0xF7, 0xF4, 0xEE)

# Fuentes
FONTS = os.path.expanduser("~/.fonts")
ANTON = os.path.join(FONTS, "Anton_400Regular.ttf")
DMSANS = os.path.join(FONTS, "DMSans_500Medium.ttf")
DMSANS_B = os.path.join(FONTS, "DMSans_700Bold.ttf")

# Tamaños (px en 1080x1920)
T_TITULO = 118
T_CLAVE = 88
T_SUB = 68
T_LISTA = 62
T_ETIQ = 44

# Zonas seguras
Z_TOP = 240
Z_BOTTOM = 1340
Z_RIGHT = 880          # nada pasa de aquí (franja derecha de 200 px)
Z_LEFT = 60
ROTULO_ZONA = (240, 640)
SUB_BASE_Y = 1330
SUB_X = 480
SUB_MAX_W = 760

# Ritmo
PAUSA_MAX = 0.30
MARGEN_PRE = 0.08
MARGEN_POST = 0.12
ZOOM_GOLPE_S = 0.14
ZOOM_GOLPE_PCT = 0.22
MAX_SIN_CAMBIO = 3.5

# Color
EQ_PRESENTE = "eq=contrast=1.06:saturation=1.10"
SEPIA = "colorchannelmixer=.563:.554:.136:0:.251:.774:.121:0:.196:.384:.374,vignette=PI/5,noise=alls=6:allf=t"
HDR2SDR = ("zscale=t=linear:npl=100,format=gbrpf32le,zscale=p=bt709,tonemap=hable:desat=0,"
           "zscale=t=bt709:m=bt709:r=tv,format=yuv420p")

# Sonido
LUFS = -14
TP = -1.5
SFX_DB = -24          # efectos por debajo de la voz (antes de normalizar)

# Exportación
X264 = ["-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18", "-preset", "veryfast",
        "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709",
        "-movflags", "+faststart"]
AAC = ["-c:a", "aac", "-ar", "48000", "-b:a", "192k"]
