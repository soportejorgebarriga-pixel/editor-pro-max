"""Portada 1080x1920: cuadro real del video + título del gancho (≤7 palabras, Anton, dorado)."""
import json, os, subprocess, sys
from PIL import Image
from config import *
import animaciones as A
import componer


def portada(ficha_path, version, salida):
    v = componer.Video(ficha_path, version)
    p = v.ficha["versiones"][v.version].get("portada", v.ficha["portada"])
    ti = [t["id"] for t in v.tomas].index(p["toma"])
    t_out = v.tout[ti][0] + p["t"]
    base = os.path.join(v.tmp, "base.mp4")
    raw = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{t_out:.3f}", "-i", base, "-frames:v", "1",
                          "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True, check=True).stdout
    fr = Image.frombytes("RGB", (W, H), raw)
    # encuadre original con un acercamiento leve en la cara
    s = 1.06
    ww, hh = W / s, H / s
    cx, cy = componer.CARA
    x0 = min(max(cx - ww / 2, 0), W - ww); y0 = min(max(cy - hh * 0.62, 0), H - hh)
    canvas = fr.resize((W, H), Image.LANCZOS, box=(x0, y0, x0 + ww, y0 + hh)).convert("RGBA")
    # degradado sutil arriba para legibilidad
    import numpy as np
    g = np.zeros((H, W, 4), np.uint8); g[..., :3] = AZUL
    g[..., 3] = (np.clip(1 - np.arange(H) / 820, 0, 1) ** 1.5 * 170).astype(np.uint8)[:, None]
    canvas.alpha_composite(Image.fromarray(g))
    yb = A.titulo(canvas, 10, 0, p["lineas"], p["y"], p.get("size", 124), oro=p.get("oro"))
    canvas.convert("RGB").save(salida, quality=95)
    return dict(titulo_y=(p["y"], yb))


if __name__ == "__main__":
    print(portada(sys.argv[1], sys.argv[2], sys.argv[3]))
